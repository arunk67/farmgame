-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jun 03, 2019 at 03:56 PM
-- Server version: 5.7.23
-- PHP Version: 7.1.22

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `gamefarm`
--

-- --------------------------------------------------------

--
-- Table structure for table `gamefarm_status`
--

DROP TABLE IF EXISTS `gamefarm_status`;
CREATE TABLE IF NOT EXISTS `gamefarm_status` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `farmer_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `cow1_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `cow2_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `bunny1_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `bunny2_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `bunny3_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `bunny4_last_fed` varchar(10) NOT NULL DEFAULT '0',
  `member_status` varchar(100) NOT NULL DEFAULT 'farmer,cow1,cow2,bunny1,bunny2,bunny3,bunny4',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
