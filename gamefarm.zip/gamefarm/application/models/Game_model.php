<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Game_model extends CI_Model {

    private $table = "gamefarm_status";

    function __construct() {
        parent::__construct();
    }

    public function getAliveMembers(){
      $query = $this->db
              ->select("$this->table.id,$this->table.farmer_last_fed,$this->table.cow1_last_fed,$this->table.cow2_last_fed,$this->table.bunny1_last_fed,$this->table.bunny2_last_fed,$this->table.bunny3_last_fed,$this->table.bunny4_last_fed,$this->table.member_status")
              ->from($this->table)
              ->order_by("$this->table.id", "desc")
              ->get();
             
              return $query; 
    }


    public function insertStatus($data){
        $this->db->insert($this->table, $data);
        return true;
    }

    public function updateStatus($data,$id){
        $this->db->update($this->table, $data, array('id' => $id));
        return true;
    }

    
    
}