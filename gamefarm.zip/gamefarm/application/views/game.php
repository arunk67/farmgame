<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
  <h2></h2>
  <p></p>
    <div class="row">
      <h2></h2>
      <p>Farm Game :</p>         
      <table class="table table-bordered" name="no_of_employees" id="no_of_employees">
        <thead>
          <tr class="active">
            <th>Turn</th>
            <th>Farmer</th>
            <th>Cow 1</th>
            <th>Cow 2</th>
            <th>Bunny 1</th>
            <th>Bunny 2</th>
            <th>Bunny 3</th>
            <th>Bunny 4</th>
          </tr>
        </thead>
        <tbody>
          <?php         
              for($i=1;$i<=50;$i++){
              ?>
              <tr>
                  <td> <?php echo "Turn $i" ?></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_farmer" id="turn<?php echo $i?>_farmer" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_cow1" id="turn<?php echo $i?>_cow1" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_cow2" id="turn<?php echo $i?>_cow2" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_bunny1" id="turn<?php echo $i?>_bunny1" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_bunny2" id="turn<?php echo $i?>_bunny2" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_bunny3" id="turn<?php echo $i?>_bunny3" readonly></div></td>
                  <td><div class="form-group"><input class="form-control align-center wd-190" type="text" name="turn<?php echo $i?>_bunny4" id="turn<?php echo $i?>_bunny4" readonly></div></td>
              </tr>
          <?php 
          } 
          ?>
        </tbody>
      </table>
    </div>
  </div>
  
  <div class="row" style="margin-left: 105px;">
    <button type="button" id="feed" name="feed" class="btn btn-success" style="">Feed</button>
  </div>

  <!-- Modal -->
  <div class="modal fade" id="modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-body" id="modalBody" name="modalBody">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  <!-- Modal -->

</body>
</html>

<script type="text/javascript">
  $(document).ready(function(){
    var turn = 1;
    $('#feed').click(function(){
      if(turn <= 50){
        $.ajax({
            url: "<?php echo site_url("startgame/analyseGame")?>",
            data: {turn : turn},
            type: 'POST',
            success:function(result){
                var res = $.parseJSON(result);
                if(res.status == "success"){
                  //////// show farmer or which animals have been fed/////////
                  $('#'+res.fedArr).val('fed');
                  $('#'+res.fedArr).css('background-color','green'); 
                  $('#'+res.fedArr).css("color", "white");
                  //////// show farmer or which animals have been dead /////////
                  if(res.deadArr.length > 0){
                    var substring = ",";
                    var contains = res.deadArr.search(substring);
                    if(contains != -1){
                      var deadMember = res.deadArr.split(',');
                      for(var i=0;i<deadMember.length;i++){
                        $('#'+deadMember[i]).val('dead');
                        $('#'+deadMember[i]).css('background-color','red');  
                        $('#'+deadMember[i]).css("color", "white");
                      }
                    }
                    //////// show farmer or which animals have been dead /////////
                    else{
                      $('#'+res.deadArr).val('dead');
                      $('#'+res.deadArr).css('background-color','red');  
                      $('#'+res.deadArr).css("color", "white");
                    }
                  }
                  
                  ////////// win condition /////////////
                  if(turn == 50){
                    //alert(res.message);
                    $("#modalBody").html(res.message);
                    $("#modal").modal('show');
                    $('#feed').attr("disabled","disabled");  
                  }
                  turn = turn + 1 ;
                }
                /////////// game over or fail condition /////////
                else if (res.status == "fail") {
                  if(res.deadArr.length > 0){
                    $('#'+res.deadArr).val('dead');
                    $('#'+res.deadArr).css('background-color','red');  
                    $('#'+res.deadArr).css("color", "white");  
                  }
                  //alert(res.message);
                  $("#modalBody").html(res.message);
                  $("#modal").modal('show');
                  $('#feed').attr("disabled","disabled");
                }
            }
          });  
      }else{
        $('#feed').attr("disabled","disabled");
      }
      
    });


  });
</script>