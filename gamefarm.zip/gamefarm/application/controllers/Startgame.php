<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Startgame extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */


	public function __construct(){
		parent::__construct();
		$this->load->model("game_model");
	}

	public function index()
	{
		$this->load->view('game');
	}

	public function analyseGame(){
		$response = array();
		$status = "success";
		$turn = $this->input->post('turn');
		//////// atleast at 8 turn no animal or framer will be killed //////////
		if($turn <= 8 ){
			$membersArray = array("farmer","cow1","cow2","bunny1","bunny2","bunny3","bunny4");
			$feedMembers = array_rand($membersArray,1);	
			if($turn == 1){
				$insert = $this->insertUpdateMemberStatus($turn,$membersArray[$feedMembers]);	
			}else{
				$getAliveMembers = $this->game_model->getAliveMembers()->row();
				if(!empty($getAliveMembers)){
					$update = $this->insertUpdateMemberStatus($turn,$membersArray[$feedMembers],$getAliveMembers->id); 			
				}
			}
			$fedArr = "turn".$turn."_".$membersArray[$feedMembers];
			$response = array("status"=>$status,"fedArr" => $fedArr,"deadArr" => "","message" => "Game On!!!");
		}
		//////////////// after turn 8, check conditions for dead or alive farmer and animals
		else{
			////////////// get details of last fed farmer and animals /////////
			$getAliveMembers = $this->game_model->getAliveMembers()->row();	
			if(!empty($getAliveMembers)){
				$deadString = "";
				$membersArray = explode(',', $getAliveMembers->member_status);
				////////////////// condition to check if farmer and atleast one cow and one bunny is alive ///////////
				if( (strpos($getAliveMembers->member_status,"farmer") !== false) && (strpos($getAliveMembers->member_status,"cow") !== false) && (strpos($getAliveMembers->member_status,"bunny") !== false) ){
					////////////// condition if farmer is dead ////////////////////////////
					if(($turn - $getAliveMembers->farmer_last_fed) > 15 ){
						if (($key = array_search("farmer", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_farmer";
						    $status = "fail";
						    $response = array("status"=>$status,"fedArr" => "","deadArr" => $deadString,"message" => "Farmer Died!!! Game Over!!!");
						    echo json_encode($response);
						    exit();
						}
					}
					////////////// condition if cow1 is dead and remove cow1 from alive members array ////////////////////////////
					if(($turn - $getAliveMembers->cow1_last_fed) > 10){
						if (($key = array_search("cow1", $membersArray)) !== false) {
						    unset($membersArray[$key]);
							$deadString .= "turn".$turn."_cow1,";    
						}
					}
					////////////// condition if cow1 is dead and remove cow2 from alive members array ////////////////////////////
					if(($turn - $getAliveMembers->cow2_last_fed) > 10){
						if (($key = array_search("cow2", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_cow2,";
						}
					}
					////////////// condition if bunny1 is dead and remove cow1 from alive members array /////////////////////////
					if(($turn - $getAliveMembers->bunny1_last_fed) > 8){
						if (($key = array_search("bunny1", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_bunny1,";
						}
					}
					////////////// condition if bunny2 is dead and remove cow1 from alive members array /////////////////////////
					if(($turn - $getAliveMembers->bunny2_last_fed) > 8){
						if (($key = array_search("bunny2", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_bunny2,";
						}
					}
					////////////// condition if bunny3 is dead and remove cow1 from alive members array /////////////////////////
					if(($turn - $getAliveMembers->bunny3_last_fed) > 8){
						if (($key = array_search("bunny3", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_bunny3,";
						}
					}
					////////////// condition if bunny4 is dead and remove cow1 from alive members array /////////////////////////
					if(($turn - $getAliveMembers->bunny4_last_fed) > 8){
						if (($key = array_search("bunny4", $membersArray)) !== false) {
						    unset($membersArray[$key]);
						    $deadString .= "turn".$turn."_bunny4,";
						}
					}
					 
					$deadString = rtrim($deadString,',');
					$feedMembers = array_rand($membersArray,1);	
					$insertUpdate = $this->insertUpdateMemberStatus($turn,$membersArray[$feedMembers],$getAliveMembers->id,$membersArray);
					$fedArr = "turn".$turn."_".$membersArray[$feedMembers];
					if($turn == 50){
						$response = array("status"=>$status,"fedArr" => $fedArr,"deadArr" => $deadString,"message" => "Congratulations!!! You won the game!!!");
					}else{
						$response = array("status"=>$status,"fedArr" => $fedArr,"deadArr" => $deadString,"message" => "Game On!!!");	
					}
					
				}
				/////////////////////////// either farmer or all cow or all bunny died //////////////////////////////////
				else{
					$status = "fail";
				    $response = array("status"=>$status,"fedArr" => "","deadArr" => "","message" => "Game Over as either Farmer died or all Cows died or all Bunnys died!!!");
				    echo json_encode($response);
				    exit();
				}
			}
			
		}
        echo json_encode($response);
	}


	////////// function to insert last fed value for farmer and animals /////////////////////
	private function insertUpdateMemberStatus($turn,$whoIsFed,$id=null,$getAliveMembers=null){
		$data = array();
		if($whoIsFed == "farmer"){
			$data = array(
				"farmer_last_fed" => $turn
			);
		}
		if($whoIsFed == "cow1"){
			$data = array(
				"cow1_last_fed" => $turn
			);	
		}
		if($whoIsFed == "cow2"){
			$data = array(
				"cow2_last_fed" => $turn
			);	
		}
		if($whoIsFed == "bunny1"){
			$data = array(
				"bunny1_last_fed" => $turn
			);
		}
		if($whoIsFed == "bunny2"){
			$data = array(
				"bunny2_last_fed" => $turn
			);	
		}
		if($whoIsFed == "bunny3"){
			$data = array(
				"bunny3_last_fed" => $turn
			);
		}
		if($whoIsFed == "bunny4"){
			$data = array(
				"bunny4_last_fed" => $turn
			);
		}
		
		if($turn == 1){
			$insertLastFed = $this->game_model->insertStatus($data);	
			return true;
		}else{
			if(!empty($getAliveMembers)){
				$finalAliveMembers = implode(',', $getAliveMembers);
				$data["member_status"] = $finalAliveMembers;
			}
			$updateLastFed = $this->game_model->updateStatus($data,$id);	
			return true;
		}
	}
}
